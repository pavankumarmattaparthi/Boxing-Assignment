using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameControler : MonoBehaviour
{
    public Button Player1, Player2;
    public Text Winer;
    public GameObject Restart;
    bool Stop;

    // Start is called before the first frame update
    void Start()
    {
        Stop = true;
        Winer.text = "";
    }

    // Update is called once per frame
    void Update()
    {
        
        if(Player1.transform.position.y>=3020)
        {
            Winer.text = "Player2 Win";
            Stop = false;
            Restart.SetActive(true);
        }

        if (Player2.transform.position.y <= -890)
        {
            Winer.text = "Player1 Win";
            Stop = false;
            Restart.SetActive(true);
        }
    }

    public void player1(int Number)
    {
        if(Stop)
        {
            Player1.transform.position = Player1.transform.position + new Vector3(0, Number, 0);
            Player2.transform.position = Player2.transform.position + new Vector3(0, Number, 0);
        }
        
    }

    public void RestartGame()
    {
        SceneManager.LoadScene(0);
    }
}
